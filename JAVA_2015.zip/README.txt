Langages de programmation: Projet java 2015
-------------------------------------------

Pour lancer le projet: 
 - Entrez la commande suivante:

	make

 - Pour afficher les temps aléatoires implémentés dans le projet il suffit de décommenter la ligne 67 du fichier ParcoursThread.java

Pour d'autre question ou problèmes:
	
	contactez moi: gtionogu@ulb.ac.be
